const EditUser = () => {
  return <h1>this is Edit</h1>;
};

export default EditUser;
